create
  definer = root@localhost procedure udp_like_article(IN p_username varchar(30), IN p_title varchar(30))
BEGIN
	IF ((select count(*) from users as u where u.username = p_username) = 0)
      THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Non-existent user.';
      ROLLBACK;
	ELSEIF ((select count(*) from articles as a where a.title = p_title) = 0)
	  THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Non-existent article.';
	  ROLLBACK;
    ELSE
	  INSERT INTO likes (article_id, comment_id, user_id)
      SELECT (SELECT id from articles where title = p_title),
      NULL,
       (SELECT id from users where username = p_username);
	END IF;
END;

