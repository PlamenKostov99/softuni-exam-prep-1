create
  definer = root@localhost function udf_users_articles_count(p_username varchar(30)) returns int
BEGIN 
    DECLARE result INT;
    SET result := 
    (
         select count(ua.article_id) from users_articles as ua
         right join  users as u
         on u.id = ua.user_id
         where u.username = p_username
    );
    RETURN result;
END;

